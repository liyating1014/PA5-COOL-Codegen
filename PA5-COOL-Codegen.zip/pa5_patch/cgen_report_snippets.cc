#include "cgen.h"
#include "emit.h"
#include "cool-tree.h"

void int_const_class::code(ostream& s, Environment env) {
  emit_load_int(ACC, inttable.lookup_string(token->get_string()), s);
}

void string_const_class::code(ostream& s, Environment env) {
  emit_load_string(ACC, stringtable.lookup_string(token->get_string()), s);
}

void bool_const_class::code(ostream& s, Environment env) {
  emit_load_bool(ACC, BoolConst(val), s);
}

void object_class::code(ostream& s, Environment env) {
  int idx;
  if ((idx = env.LookUpVar(name)) != -1) {
    emit_load(ACC, idx + 1, SP, s);
  } else if ((idx = env.LookUpParam(name)) != -1) {
    emit_load(ACC, idx + 3, FP, s);
  } else if ((idx = env.LookUpAttrib(name)) != -1) {
    emit_load(ACC, idx + 3, SELF, s);
  } else if (name == self) {
    emit_move(ACC, SELF, s);
  }
}

void assign_class::code(ostream& s, Environment env) {
  expr->code(s, env);

  int idx;
  if ((idx = env.LookUpVar(name)) != -1) {
    emit_store(ACC, idx + 1, SP, s);
  } else if ((idx = env.LookUpParam(name)) != -1) {
    emit_store(ACC, idx + 3, FP, s);
  } else if ((idx = env.LookUpAttrib(name)) != -1) {
    emit_store(ACC, idx + 3, SELF, s);
    if (cgen_Memmgr == 1) {
      emit_addiu(A1, SELF, 4 * (idx + 3), s);
      emit_jal("_GenGC_Assign", s);
    }
  }
}

void plus_class::code(ostream& s, Environment env) {
  e1->code(s, env);
  emit_push(ACC, s);
  env.AddObstacle();

  e2->code(s, env);
  emit_jal("Object.copy", s);

  emit_load(T1, 1, SP, s);
  emit_addiu(SP, SP, 4, s);

  emit_move(T2, ACC, s);

  emit_load(T1, 3, T1, s);
  emit_load(T2, 3, T2, s);

  emit_add(T3, T1, T2, s);
  emit_store(T3, 3, ACC, s);
}

void cond_class::code(ostream& s, Environment env) {
  pred->code(s, env);
  emit_fetch_int(T1, ACC, s);

  int label_false = labelnum++;
  int label_finish = labelnum++;

  emit_beq(T1, ZERO, label_false, s);

  then_exp->code(s, env);
  emit_branch(label_finish, s);

  emit_label_def(label_false, s);
  else_exp->code(s, env);

  emit_label_def(label_finish, s);
}

void dispatch_class::code(ostream& s, Environment env) {
  expr->code(s, env);

  int label_ok = labelnum++;
  emit_bne(ACC, ZERO, label_ok, s);
  emit_load_address(ACC, "str_const0", s);
  emit_load_imm(T1, 1, s);
  emit_jal("_dispatch_abort", s);
  emit_label_def(label_ok, s);

  Symbol class_name = env.m_class_node->name;
  if (expr->get_type() != SELF_TYPE) {
    class_name = expr->get_type();
  }

  emit_load(T1, 2, ACC, s);
  int idx = codegen_classtable->GetClassNode(class_name)->GetDispatchIdxTab()[name];
  emit_load(T1, idx, T1, s);
  emit_jalr(T1, s);
}

void new__class::code(ostream& s, Environment env) {
  if (type_name == SELF_TYPE) {
    emit_load_address(T1, "class_objTab", s);
    emit_load(T2, 0, SELF, s);
    emit_sll(T2, T2, 3, s);
    emit_addu(T1, T1, T2, s);

    emit_push(T1, s);

    emit_load(ACC, 0, T1, s);
    emit_jal("Object.copy", s);

    emit_load(T1, 1, SP, s);
    emit_addiu(SP, SP, 4, s);

    emit_load(T1, 1, T1, s);
    emit_jalr(T1, s);
  } else {
    std::string protobj = type_name->get_string() + PROTOBJ_SUFFIX;
    emit_load_address(ACC, protobj.c_str(), s);
    emit_jal("Object.copy", s);

    std::string init = type_name->get_string() + CLASSINIT_SUFFIX;
    emit_jal(init.c_str(), s);
  }
}

void CgenClassTable::code_constants() {
  stringtable.add_string("");
  inttable.add_string("0");

  stringtable.code_string_table(str, stringclasstag);
  inttable.code_string_table(str, intclasstag);

  code_bools(boolclasstag);
}

void CgenClassTable::code_class_nameTab() {
  str << CLASSNAMETAB << LABEL;

  std::vector<CgenNode*> class_nodes = GetClassNodes();
  for (CgenNode* class_node : class_nodes) {
    Symbol class_name = class_node->name;
    StringEntry* str_entry = stringtable.lookup_string(class_name->get_string());

    str << WORD;
    str_entry->code_ref(str);
    str << endl;
  }
}

void CgenClassTable::code_dispatchTabs() {
  std::vector<CgenNode*> class_nodes = GetClassNodes();

  for (CgenNode* class_node : class_nodes) {
    emit_disptable_ref(class_node->name, str);
    str << LABEL;

    std::vector<method_class*> methods = class_node->GetFullMethods();
    for (method_class* method : methods) {
      str << WORD;
      emit_method_ref(class_node->name, method->name, str);
      str << endl;
    }
  }
}

void CgenNode::code_protObj(ostream& s) {
  std::vector<attr_class*> attribs = GetFullAttribs();

  s << WORD << "-1" << endl;
  s << get_name() << PROTOBJ_SUFFIX << LABEL;

  s << WORD << class_tag << endl;
  s << WORD << (DEFAULT_OBJFIELDS + attribs.size()) << endl;
  s << WORD << get_name() << DISPTAB_SUFFIX << endl;

  for (attr_class* attr : attribs) {
    if (attr->type_decl == Int) {
      s << WORD;
      inttable.lookup_string("0")->code_ref(s);
      s << endl;
    } else if (attr->type_decl == Bool) {
      s << WORD;
      falsebool.code_ref(s);
      s << endl;
    } else if (attr->type_decl == Str) {
      s << WORD;
      stringtable.lookup_string("")->code_ref(s);
      s << endl;
    } else {
      s << WORD << "0" << endl;
    }
  }
}

void CgenNode::code_init(ostream& s) {
  s << get_name() << CLASSINIT_SUFFIX << LABEL;

  emit_addiu(SP, SP, -12, s);
  emit_store(FP, 3, SP, s);
  emit_store(SELF, 2, SP, s);
  emit_store(RA, 1, SP, s);
  emit_addiu(FP, SP, 4, s);
  emit_move(SELF, ACC, s);

  Symbol parent = get_parentnd()->name;
  if (parent != No_class) {
    emit_jal(parent->get_string() + CLASSINIT_SUFFIX, s);
  }

  std::vector<attr_class*> attribs = GetAttribs();
  std::map<Symbol, int> idx_tab = GetAttribIdxTab();

  for (attr_class* attr : attribs) {
    int idx = idx_tab[attr->name];

    if (attr->init->IsEmpty()) {
      if (attr->type_decl == Str) {
        emit_load_string(ACC, stringtable.lookup_string(""), s);
      } else if (attr->type_decl == Int) {
        emit_load_int(ACC, inttable.lookup_string("0"), s);
      } else if (attr->type_decl == Bool) {
        emit_load_bool(ACC, BoolConst(0), s);
      }
    } else {
      Environment env;
      env.m_class_node = this;
      attr->init->code(s, env);
    }

    emit_store(ACC, 3 + idx, SELF, s);
  }

  emit_move(ACC, SELF, s);

  emit_load(FP, 3, SP, s);
  emit_load(SELF, 2, SP, s);
  emit_load(RA, 1, SP, s);
  emit_addiu(SP, SP, 12, s);
  emit_return(s);
}
