#pragma once

class CgenNode;
class Symbol;

class Environment {
public:
  int LookUpVar(Symbol sym);
  int LookUpParam(Symbol sym);
  int LookUpAttrib(Symbol sym);

  void EnterScope();
  void ExitScope();

  void AddVar(Symbol sym);
  void AddParam(Symbol sym);

  void AddObstacle();

  CgenNode* m_class_node;
};
