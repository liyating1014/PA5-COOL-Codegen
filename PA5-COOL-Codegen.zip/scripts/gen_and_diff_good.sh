#!/usr/bin/env bash
set -euo pipefail

FILE="tests/good.cl"

./lexer "$FILE" | ./parser "$FILE" 2>&1 | ./mycgen "$FILE" 2>&1 > my_good.s
./lexer "$FILE" | ./parser "$FILE" 2>&1 | /usr/class/bin/cgen "$FILE" 2>&1 > official_good.s

diff my_good.s official_good.s || true
