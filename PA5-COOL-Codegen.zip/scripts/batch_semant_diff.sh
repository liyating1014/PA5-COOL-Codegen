#!/usr/bin/env bash
set -euo pipefail

FILES=("good.cl" "stack.cl" "complex.cl")

for file in "${FILES[@]}"; do
  echo "Testing $file..."

  ./lexer "$file" | ./parser "$file" 2>&1 | /usr/class/bin/semant "$file" 2>&1 > "official_${file%.cl}.txt"
  ./lexer "$file" | ./parser "$file" 2>&1 | ./mysemant "$file" 2>&1 > "my_${file%.cl}.txt"

  if diff "official_${file%.cl}.txt" "my_${file%.cl}.txt" >/dev/null; then
    echo "OK: $file"
  else
    echo "DIFF: $file"
    diff "official_${file%.cl}.txt" "my_${file%.cl}.txt" | head -n 20
  fi
done
